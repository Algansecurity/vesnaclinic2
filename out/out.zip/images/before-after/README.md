# Before/After Fotoğrafları

Bu klasörde Vesna Hair Clinic'in before/after fotoğrafları bulunmalıdır.

## Gerekli Dosyalar:
- before-1.jpg - before-8.jpg (8 adet before fotoğrafı)
- after-1.jpg - after-8.jpg (8 adet after fotoğrafı)

## Önerilen Boyut:
- 800x600 piksel
- JPG format
- Optimized for web

## Notlar:
Gerçek hasta fotoğraflarını https://vesnahairclinic.com/before-after/ adresinden alabilirsiniz. 